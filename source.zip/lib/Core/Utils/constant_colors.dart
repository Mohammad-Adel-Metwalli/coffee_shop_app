import 'package:flutter/material.dart';

const babyPowder = Color(0xffFBFEFB);
const brown = Color(0xFF783920);
const luxuryBlue = Color(0xff0028ce);
const customedGrey = Colors.grey;
const green = Color(0xff208b3a);
const customedRed = Colors.red;
const orange = Color(0xffff9e00);