class UserModel
{
  String username, email, password;

  UserModel(this.username, this.password, this.email);
}